#!/bin/bash
exec ./procsim "$@"
